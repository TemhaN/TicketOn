<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>

  <nav class="navbar navbar-expand-lg bg-dark border-bottom border-body">
  <div class="container ">
    <a class="navbar-brand text-light" href="#">EuroSkills Concerts</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
      <div class="d-flex align-items-center " role="tickets">
        <span class="text-light me-2">Already booked?</span>
        <button class="btn btn-outline-success" type="submit">Get tickets</button>
      </div>
    </div>
  </div>
</nav>
  <div class="container">
    <RouterView />
  </div>
</template>

<style scoped>

</style>
