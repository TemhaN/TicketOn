<script setup>

</script>

<template>
<h1 class="text-center mt-5">Checkout these amazing concerts in Graz</h1>
<div class="row mt-4">
  <div class="col-md-4">
    <select class="form-select" aria-label="Default select example">
      <option selected>Artist</option>
      <option value="1">One</option>
      <option value="2">Two</option>
      <option value="3">Three</option>
    </select>
  </div>
  <div class="col-md-4">
    <select class="form-select" aria-label="Default select example">
      <option selected>Location</option>
      <option value="1">One</option>
      <option value="2">Two</option>
      <option value="3">Three</option>
    </select>
  </div>
  <div class="col-md-4">
    <input type="date" class="form-control">
  </div>

  <div class="row row-cols-1 row-cols-md-3 g-4">
  <div class="col">
    <div class="card h-100">
      <img src="..." class="card-img-top" alt="...">
      <div class="card-body text-center">
        <p class="card-text">13.05.2024</p>
        <h5 class="card-title font-weight-bold">Artist</h5>
        <p class="card-text">location</p>
        <p class="card-text">12:00-13:00</p>
      </div>
    </div>
  </div>
  
</div>
</div>
</template>
