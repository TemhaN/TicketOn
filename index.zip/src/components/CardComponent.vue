<script setup>
defineProps({
	title: {
		type: String,
		required: true,
	},
	id: {
		type: Number,
		required: true,
	},
	start: {
		type: Number,
		required: true,
	},
	end: {
		type: Date,
		required: true,
	},
	location: {
		type: String,
		required: true,
	},
});
</script>
<template>
	<div class="card h-100">
		<div class="card-body text-center">
			<p class="card-text">{{ start.toLocaleDateString }}</p>
			<h5 class="card-title font-weight-bold">Artist</h5>
			<p class="card-text">location</p>
			<p class="card-text">12:00-15:00</p>
		</div>
	</div>
</template>

<style scoped></style>
